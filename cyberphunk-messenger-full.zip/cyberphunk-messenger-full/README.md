# 🛡️ Cyberphunk Messenger

A secure, cyberpunk-themed end-to-end encrypted messaging app built with:

- ⚛️ Next.js
- 🌐 Cloudflare Workers (KV + API)
- 🔐 AES-GCM WebCrypto for E2EE
- 🕸️ WebRTC for peer-to-peer (optional)

## 🔧 Setup

```bash
npm install
npm run dev
```

## 🚀 Deploy to Cloudflare

Install Wrangler CLI and set your credentials in `wrangler.toml`. Then:

```bash
npx wrangler deploy
```
