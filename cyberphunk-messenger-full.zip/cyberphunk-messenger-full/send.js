export default {
  async fetch(request, env) {
    if (request.method === "POST") {
      const { encrypted } = await request.json();
      const id = crypto.randomUUID();
      const timestamp = new Date().toISOString();
      await env.MESSAGES.put(id, JSON.stringify({ encrypted, timestamp }));
      return new Response("Stored", { status: 200 });
    }

    if (request.method === "GET") {
      const list = await env.MESSAGES.list();
      const messages = await Promise.all(
        list.keys.map(async (key) => {
          const value = await env.MESSAGES.get(key.name);
          return JSON.parse(value);
        })
      );
      return new Response(JSON.stringify(messages), {
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response("Method Not Allowed", { status: 405 });
  },
};
