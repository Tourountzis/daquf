import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ShieldCheck, SendHorizonal } from "lucide-react";
import { motion } from "framer-motion";

export default function CyberpunkMessenger() {
  const [message, setMessage] = useState("");
  const [log, setLog] = useState([]);
  const [cryptoKey, setCryptoKey] = useState(null);

  const generateKey = async () => {
    const key = await window.crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt", "decrypt"]
    );
    setCryptoKey(key);
  };

  const encryptMessage = async (text) => {
    if (!cryptoKey) return btoa(text);
    const encoder = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encryptedContent = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      cryptoKey,
      encoder.encode(text)
    );
    return btoa(JSON.stringify({ iv: Array.from(iv), data: Array.from(new Uint8Array(encryptedContent)) }));
  };

  const decryptMessage = async (encryptedBase64) => {
    if (!cryptoKey) return atob(encryptedBase64);
    const { iv, data } = JSON.parse(atob(encryptedBase64));
    const decrypted = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(iv) },
      cryptoKey,
      new Uint8Array(data)
    );
    return new TextDecoder().decode(decrypted);
  };

  const handleSend = async () => {
    if (!message.trim()) return;
    const encrypted = await encryptMessage(message);
    setLog((prev) => [...prev, { text: encrypted, timestamp: new Date().toISOString(), type: "sent" }]);
    setMessage("");

    await fetch("https://cyberphunk-messenger.your-subdomain.workers.dev", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ encrypted }),
    });
  };

  const handleDecrypt = async (encryptedText) => {
    const decrypted = await decryptMessage(encryptedText);
    alert(`Decrypted: ${decrypted}`);
  };

  return (
    <div className="min-h-screen bg-black text-green-400 p-4 font-mono">
      <motion.h1 className="text-3xl mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <ShieldCheck className="inline-block mr-2" />Cyberphunk Messenger
      </motion.h1>
      <Button onClick={generateKey} className="mb-4 bg-purple-700 hover:bg-purple-500">
        Generate Encryption Key
      </Button>
      <Card className="bg-gray-900 border border-green-700 p-4">
        <CardContent className="space-y-4">
          <div className="overflow-y-auto h-64 bg-black border border-green-600 p-2 rounded">
            {log.map((msg, index) => (
              <div
                key={index}
                className="text-sm cursor-pointer hover:underline"
                onClick={() => handleDecrypt(msg.text)}
              >
                [{new Date(msg.timestamp).toLocaleTimeString()}] ➜ {msg.text}
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your encrypted message"
              className="bg-black border-green-500 text-green-400"
            />
            <Button onClick={handleSend} className="bg-green-700 hover:bg-green-500">
              <SendHorizonal className="mr-2" />Send
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
